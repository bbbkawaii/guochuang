const stages = [
  {
    name: '水解',
    step: '01',
    en: 'HYDROLYSIS',
    title: '大分子原料被逐步分解',
    text: '果蔬、秸秆等原料中的复杂有机物开始被微生物与酶系拆解，为后续产酸和菌群演替提供底物。',
    points: ['原料软化与溶出', '可利用糖和小分子增加', '发酵体系开始活跃']
  },
  {
    name: '产酸',
    step: '02',
    en: 'ACIDIFICATION',
    title: '有机酸积累，快速建立优势环境',
    text: '乳酸、乙酸等酸性物质逐步积累，pH 下降；酸性环境与有益微生物协同占位，抑制杂菌和部分病原菌。',
    points: ['乳酸、乙酸等增加', 'pH 持续下降', '酸菌协同抑制有害菌']
  },
  {
    name: '后熟',
    step: '03',
    en: 'MATURATION',
    title: '体系趋于稳定，活性物质继续转化',
    text: '微生物群落和代谢物组成逐步稳定，原料进一步分解，形成更适合储存与农业应用的成熟发酵体系。',
    points: ['气味与状态趋稳', '菌群结构稳定', '进入应用与储存阶段']
  }
]

const rawMaterials = [
  { mark: '果', tone: 'green', name: '废弃瓜果蔬菜', use: '补充有机质和有益微生物，改善板结、酸碱与保水保肥能力。' },
  { mark: '养', tone: 'gold', name: '动物源原料', use: '可提供氨基酸、多肽及中微量元素，用于生根壮苗与营养补给。' },
  { mark: '药', tone: 'red', name: '中药材残渣', use: '富含生物碱、黄酮、多酚等成分，可用于病虫害综合防控探索。' }
]

const process = [
  { index: '01', title: '原料分类与预处理', text: '剔除明显污染物，按用途选择果蔬、动物源或中药材原料。' },
  { index: '02', title: '配比与接种', text: '依据标准化工艺加入糖源、菌种等，控制装料量与容器清洁。' },
  { index: '03', title: '密封厌氧发酵', text: '记录日期、原料、批次、pH 与气味变化，减少杂菌污染。' },
  { index: '04', title: '成熟判断与应用', text: '经技术人员确认成熟后，按作物、场景和功能确定稀释与施用方式。' }
]

Page({
  data: {
    stages,
    activeStage: 1,
    currentStage: stages[1],
    rawMaterials,
    process
  },
  selectStage(event) {
    const index = Number(event.currentTarget.dataset.index)
    this.setData({ activeStage: index, currentStage: stages[index] })
  },
  goResults() {
    wx.switchTab({ url: '/pages/result/result' })
  },
  onShareAppMessage() {
    return {
      title: '三分钟看懂农用酵素｜水解、产酸、后熟',
      path: '/pages/tech/tech'
    }
  },
  onShareTimeline() {
    return { title: '三分钟看懂农用酵素的三阶段原理' }
  }
})
