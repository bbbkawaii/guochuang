App({
  globalData: {
    projectName: '瑞土酵生',
    version: '1.0.0'
  },
  onLaunch() {
    const launchCount = wx.getStorageSync('launchCount') || 0
    wx.setStorageSync('launchCount', launchCount + 1)
  }
})
